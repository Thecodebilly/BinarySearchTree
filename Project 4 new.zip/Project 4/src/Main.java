/**
*The method calls Project3.java and initiates the program
*
*Billy Shaw
*3/15/2020
*/
	import java.io.FileNotFoundException;
import java.util.*; 
public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		boolean end=false;
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter the name of a file:");
		
		String FileName = in.nextLine();
	
		Project4 Project4 = new Project4();
			
		Project4.useProject4(FileName);
		//Project.useProject1(FileName);
		
		in.close();
	}

	
	
	}

