 class node {
 String name;
double gdpPerCapita;
 node leftChild;
 node rightChild;
 public node(String name, double gdpPerCapita) {
 this.name = name;
this.gdpPerCapita = gdpPerCapita;
 }
 public void printNode() {
 System.out.printf("%-25s%,-20.2f\n", name, gdpPerCapita);
 }
}






}

