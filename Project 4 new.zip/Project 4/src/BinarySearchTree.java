
public class BinarySearchTree {

	private node root;
	public BinarySearchTree () 
	{}
	
	public void insert(String name, double gdpPerCapita) 
	{
		node newNode= new node();
		newNode.gdpPerCapita=gdpPerCapita;
		newNode.name=name;
		if (root==null)
		{
			root=newNode;
		}
		else
		{
		 node current= root;
		 node parent;
		 while(true) 
		 {
		parent=current;
		if (current.name.compareTo(name)>0)
		{
			current = current.leftChild;
			if (current== null) 
			{
			parent.leftChild=newNode;
			return;
			}
			}
	
		 else
		 {
		current= current.rightChild;
		if (current==null)
		{
			parent.rightChild=newNode;
			return;
		} 
		} //end go right
		} //end loop
		} //end else not root 
		} //end insert method
		
	
	public double find (String name)
	{
		
	}
	
	public void delete(String name)
	{
		
		node current = root;
		node parent= root;
		boolean isLeftChild =true;
		
		while (current.name.compareTo(name)!=0)
		{
			parent=current;
			if (current.name.compareTo(name)>0)
			{
				
			}
		
		
		
		
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	public void printInorder()
	{
		
	}
	
	public void printPreorder()
	{
		
	}
	
	public void printPostorder()
	{
	}
	
	public void printBottomFive()
	{
		//use book last method and edit it to print the last 5
	}
	
	public void printTopFive()
	{
		//use inverse the last method
	}
	
	
	
}
