/**
* COP 3538: Project 3 � Stacks and Priority Queues
* 
*
*The purpose of this class is to in-take the .csv file name from the user and manipulates the stacks and queues being used in the program.
* 
* 
* Billy Shaw
* 3-15-2020
* */
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class Project4 {
	public static void useProject4(String FileName) throws FileNotFoundException {
	
		
	File file = new File(FileName); 
		Scanner s = new Scanner(file);
		
    ArrayList<Country> arlist= new ArrayList<Country>();
    
    
   
    
    //here you call country.java and use the constructor in order to create the objects
    //at this point the objects are created

    s.nextLine();
	
   do
    {
    	arlist.add(new Country(s.nextLine()));	    
    }	     while (s.hasNextLine());
    		
   				int x=arlist.size();
   
    		 Country[] Countries = new Country [x];
    		 
    		 int i=0;
    while (i<x)
    {
    	Countries[i]=arlist.get(i);
    	i++;
    }
   
 
    stackList All = new stackList();
    stackList Excellent= new stackList();
    stackList VGood= new stackList();
    stackList Good= new stackList();
    stackList Fair= new stackList();
    stackList Poor= new stackList();
    
    
    i=0;
    while (i<x)
    {
    if (Countries[i].getNewGDP()/Countries[i].getPopulation()>=50000 )
    {
    	All.Push(Countries[i]);
    }
    else if(Countries[i].getNewGDP()/Countries[i].getPopulation()<50000 && Countries[i].getNewGDP()/Countries[i].getPopulation()>=20000)
    {
    	VGood.Push(Countries[i]);
    }
    else if(Countries[i].getNewGDP()/Countries[i].getPopulation()<20000 && Countries[i].getNewGDP()/Countries[i].getPopulation()>=5000)
    {
    	All.Push(Countries[i]);
    }
    else if(Countries[i].getNewGDP()/Countries[i].getPopulation()<5000 && Countries[i].getNewGDP()/Countries[i].getPopulation()>=1000)
    {
    	Fair.Push(Countries[i]);
    }
    else if (Countries[i].getNewGDP()/Countries[i].getPopulation()<1000 && Countries[i].getNewGDP()/Countries[i].getPopulation()>=0)
    {
    	All.Push(Countries[i]);
    }
    i++;
    }
    
   
    
    
   System.out.println("Stack contents:");
   All.printStack();
  
   
   
   QueueList Queue= new QueueList(); 
   
   
   int e=0; 
   while (All.isEmpty()==false)
   {
	   if (e%2==0)
	   {
		   Queue.insertFirst(All.Pop());
	   }
	   else
		   Queue.insertLast(All.Pop());
	   e++;
   }
  
   System.out.println("Queue contents:");
   Queue.printQueue();
   
   
   
   Queue.intervalDelete(50000, 70000);
   System.out.println("Queue contents:");
   Queue.printQueue();
   
 
   
   
   e=0;
  while (Queue.isEmpty()==false)
  {
	  if (e%2==0)
	   {
		   All.Push(Queue.deleteFirst().linkCountry);
	   }
	   else
		   All.Push((Queue.deleteLast().linkCountry));
		   e++;
  }
  
  
  
  System.out.println("Stack contents:");
  All.printStack();
  s.close();
	}
    
    
   
}

