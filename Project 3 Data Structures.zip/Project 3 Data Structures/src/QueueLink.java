/**
* COP 3538: Project 3 � Stacks and Priority Queues
* 
*
*The purpose of this class is to create link objects that can be used for singly-linked lists.
* 
* Billy Shaw
* 3-15-2020
* */
public class QueueLink {
	Country linkCountry;
	public QueueLink next;
	public QueueLink previous;


public QueueLink (Country L) {
this.linkCountry=L;
}
/* This method prints out the country in the link object*/
public void displayLink ()
{
	linkCountry.printCountry(linkCountry);
}
}


