/**
* COP 3538: Project 3 � Stacks and Priority Queues
* 
*
*This class allows for the use of a queue using a double-ended doubly-linked list 
* 
* Billy Shaw
* 3-15-2020
* */
public class QueueList {
private QueueLink first;
private QueueLink last;

public QueueList ()
{
	first=null;
	last=null;
}
/*This method checks if the queue is empty*/
public boolean isEmpty() {
	return first==null;
}
/*This method inserts a link with an associated country into the front of the queue*/
public void insertFirst (Country C)
{
	QueueLink newQueueLink = new QueueLink (C);
	
	if (isEmpty())
	{
		last= newQueueLink;
	}
	else
		first.previous=newQueueLink;

	newQueueLink.next=first;
	first = newQueueLink;
}
/*This method inserts a link with an associated country into the back of the queue*/
public void insertLast (Country C)
{
	QueueLink newQueueLink = new QueueLink (C);
	if (isEmpty())
	{
		first= newQueueLink;
	}
	else {
		last.next=newQueueLink;
		newQueueLink.previous=last;
	}
	last=newQueueLink;	
}
/*This method deletes a link with an associated country from the front of the queue, and returns that link*/
public QueueLink deleteFirst() {
	
	QueueLink temp = first;
	if (first.next==null)
	{
		last=null;
	}
	else 
		first.next.previous=null;
	first=first.next;
	return temp;
}
/*This method deletes a link with an associated country from the back of the queue, and returns the associated country*/
public QueueLink deleteLast ()
{
	QueueLink temp=last;
	if (first.next == null)
	
		first=null;
	
	else 
	
		last.previous.next=null;
	
	last=last.previous;
	return temp;
}
/*This method prints the queue from the front to the back*/
public void printQueue()
{
	System.out.printf("Country Name:\t\t              Country Code:     Captiol City:   Population:         GDP:                   Happiness Rank:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
	
	QueueLink current=first;
while (current!=null)
{
	current.displayLink();
current=current.next;
}
}
/*This method deletes a specific link from the queue, which is determined by the parameter link*/
public void deleteSpecificLink (QueueLink Link)
{
	
	QueueLink temp= first;
	if (Link==first)
	{
		deleteFirst();
	}
	if (Link==last) 
	{
		deleteLast();
	}
	
	while (temp.next!=null)
	{
		if (Link==temp)
	
	{
		Link.previous.next=Link.next;
		Link.next.previous=Link.previous;
	}
	temp=temp.next;
	}
}
/*This method determines if the queue is full*/
public boolean isFull ()
{
	return false;
}
/*This method deletes links with a GDP per capita less than the high bound, but higher than the low bound passed into the parameters, then returns true if any values were deleted.*/
public boolean intervalDelete(int low, int high)
{
	
	boolean delete=false;
	QueueLink Current=first;
	while (Current.next!=null)
	{
		if (Current.linkCountry.getNewGDP()/Current.linkCountry.getPopulation()<high && Current.linkCountry.getNewGDP()/Current.linkCountry.getPopulation()>low)
		{
						
				Current.previous.next=Current.next;
				Current.next.previous=Current.previous;
			
				delete=true;
			}
		
			Current=Current.next;
		}
	
	
	return delete;
}

































}
