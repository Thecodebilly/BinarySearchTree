/**
* COP 3538: Project 3 � Stacks and Priority Queues
* 
*
*This class creates a stack using a double-ended singly-linked list of objects.
* 
* Billy Shaw
* 3-15-2020
* */
public class stackList {

	
	private Link first;
	private Link last;
	
	public stackList ()
	{
		first=null;
		last=null;
	}
	/*This method checks if the stack is empty*/
	public boolean isEmpty ()
	{
		return first==null;
	}
	/*This method checks if the stack is full*/
	public boolean isFull ()
	{
		return false;
	}
	/*This method inserts a link with an associated country into the stack*/
	public void Push (Country country)
	{
		Link newLink = new Link(country);
		
		if (isEmpty ())
		{
			last=newLink; 
		}
	newLink.next=first;
	first=newLink;
	}
	/*This method takes a link off the top of the stack and returns it*/
	public Country Pop ()
	{
	Country temp = first.linkCountry;
	if (first.next==null)
	{
		last=null;
	}
	first=first.next;
	return temp;
	}
	/*This method prints the stack from top to bottom*/
	public void printStack () {
		Link current = first;
		System.out.printf("Country Name:\t\t              Country Code:     Captiol City:   Population:         GDP:                   Happiness Rank:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
		
	 while (current!=null)
	 {
		 current.displayLink();
		 current=current.next;
	 }
		System.out.println("");
	}
	
	
	
	
	
}
