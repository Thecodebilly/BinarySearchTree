/*
*This class allows for the use of a priority queue by using an array and various methods.
*
*
*
*
*
*Billy Shaw
*2/21/2020
*/
public class Priority 
	{
	// array in sorted order, from max at 0 to min at size-1
	private int maxSize;
	private Country[] queArray;
	private int nItems;
	//-------------------------------------------------------------
	public Priority(int s) // constructor
	{
	maxSize = s;
	queArray = new Country[maxSize];
	nItems = 0;
	}
	
	//-------------------------------------------------------------
	public void insert(Country item) // insert item
	{
	int j;
	if(nItems==0) // if no items,
	queArray[nItems++] = item; // insert at 0
	else // if items,
	{
	for(j=nItems-1; j>=0; j--) // start at end,
	{
	if( item.getNewGDP()/item.getPopulation() > queArray[j].getNewGDP()/queArray[j].getPopulation() ) // if new item larger,
	queArray[j+1] = queArray[j]; // shift upward
	else // if smaller,
	break; // done shifting
	} // end for
	queArray[j+1] = item; // insert it
	nItems++;
	} // end else (nItems > 0)
	} // end insert()
	/*The insert method takes a country as a parameter and inserts it into the queue in order based on GDP per capita.*/
	//-------------------------------------------------------------
	public Country remove() // remove minimum item
	{ return queArray[--nItems]; }
	/*The remove method the item that is first in line from the queue*/
	//-------------------------------------------------------------
	public Country peekMin() // peek at minimum item
	{ return queArray[nItems-1]; }
	/*The peekMin method returns the item that is first in line in the queue*/
	//-------------------------------------------------------------
	public boolean isEmpty() // true if queue is empty
	{ return (nItems==0); }
	/*The isEmpty method checks if the queue has no items in it*/
	//-------------------------------------------------------------
	public boolean isFull() // true if queue is full
	{ return (nItems == maxSize); }
	/*The isFull method checks if the queue has items in it*/
	//-------------------------------------------------------------
	public void printPriority()
	{
		int x=0;
		while (x<nItems)
		{
			System.out.printf("%-35s   %-17s %-15s %-15d     %-3.2e               %-10d\n",queArray[x].getName(),queArray[x].getCode(), queArray[x].getCapitol(),queArray[x].getPopulation(),queArray[x].getNewGDP(),queArray[x].getHappinessRank());
			x++;
		}
	}
	/*The printPriority method prints every element in the priority queue*/
	} // end class PriorityQ

