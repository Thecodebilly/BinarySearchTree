/**
*This class allows for the construction and formatting of a .csv file into an array of countries to be made 
*
*
*
*
*Billy Shaw
*2/21/2020
*/
public class Country {

	
	private String Name;
	private String Code;
	private String Capitol; 
	private long Population;
	private double newGDP;
	private int HappinessRank;
	public String z;
	
	public int i=0;
	 public Country (String z) {
	
		String[]temp  = z.split(",");
	
		i=0;
		
	
	this.setName(temp [0]);
	this.setCode(temp [1]);
	this.setCapitol(temp [2]);
	this.setPopulation(Long.parseLong(temp[3]));
	this.setNewGDP(Double.parseDouble(temp[4]));
	this.setHappinessRank(Integer.parseInt(temp[5]));
	
	 }
	
	public void printCountry (Country One)
	{
		System.out.printf("Country Name:\t%s\nCountry Code:\t%s\nCaptiol City:\t%s\nPopulation:\t%d\nGDP:\t\t%3.2e\nHappiness Rank: %d\n",One.getName(),One.getCode(), One.getCapitol(),One.getPopulation(),One.getNewGDP(),One.getHappinessRank());
	}
	/*This method prints a country and its attributes*/
	public String getName() {
		return Name;
	}
	/*Getter for country name*/
	public void setName(String name) {
		Name = name;
	}
	/*Setter for country name*/
	public String getCode() {
		return Code;
	}
	/*Getter for country code*/
	public void setCode(String code) {
		Code = code;
	}
	/*Setter for country code*/
	public String getCapitol() {
		return Capitol;
	}
	/*Getter for country capitol*/
	public void setCapitol(String capitol) {
		Capitol = capitol;
	}
	/*Setter for country capitol*/
	public long getPopulation() {
		return Population;
	}
	/*Getter for country population*/
	public void setPopulation(long l) {
		Population = l;
	}
	/*Setter for country population*/
	public double getNewGDP() {
		return newGDP;
	}
	/*Getter for country GDP*/
	public void setNewGDP(Double d) {
		this.newGDP = d;
	}
	/*Setter for country GDP*/
	public int getHappinessRank() {
		return HappinessRank;
	}
	/*Getter for country happiness rank*/
	public void setHappinessRank(int happinessRank) {
		this.HappinessRank = happinessRank;
	}
	/*Setter for country happiness rank*/
	
	
	
	
	
	
	
	

}
