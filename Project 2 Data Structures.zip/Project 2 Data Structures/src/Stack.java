/**
*This class allows for the use of a stack by using an array and various methods.
*
*
*
*
*Billy Shaw
*2/21/2020
*/
public class Stack 
	{
	private int maxSize; // size of stack array
	private Country[] stackArray;
	private int top; // top of stack
	//--------------------------------------------------------------
	public Stack(int s) // constructor
	{
	maxSize = s; // set array size
	stackArray = new Country[maxSize]; // create array
	top = -1; // no items yet
	}
	//--------------------------------------------------------------
	public void push(Country j) // put item on top of stack
	{
	stackArray[++top] = j; // increment top, insert item
	}
	/*The push method takes the country you are putting into the stack as a parameter, increases the amount of elements and stores it.
	*/
	//--------------------------------------------------------------
	public Country pop() // take item from top of stack
	{
	return stackArray[top--];// access item, decrement top
	}
	/*The pop method removes an element from the stack, reduces the amount of elements in the stack and returns the element you removed. */
	//--------------------------------------------------------------
	public Country peek() // peek at top of stack
	{
	return stackArray[top];
	}
	/*The peek method looks into the top of the stack and does not alter the stack itself*/
	//--------------------------------------------------------------
	public boolean isEmpty() // true if stack is empty
	{
	return (top == -1);
	}
	/*The isEmpty method checks if the stack being referenced is empty*/
	//--------------------------------------------------------------
	public boolean isFull() // true if stack is full
	{
	return (top == maxSize-1);
	}
	/*The isFull method checks if the stack being referenced is full*/
	public void printStack()
	{
		int x=0;
		while (x<maxSize)
		{
			System.out.printf("%-35s   %-17s %-15s %-15d     %-3.2e               %-10d\n",stackArray[x].getName(),stackArray[x].getCode(), stackArray[x].getCapitol(),stackArray[x].getPopulation(),stackArray[x].getNewGDP(),stackArray[x].getHappinessRank());
			
			x++;
		}
	}
	/*The printStack method prints out all the elements in the array*/
	//--------------------------------------------------------------
	} // end class StackX

