/**
*The method calls Project2.java and initiates the program
*
*Billy Shaw
*2/21/2020
*/
	import java.io.FileNotFoundException;
import java.util.*; 
public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		boolean end=false;
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter the name of a file:");
		
		String FileName = in.nextLine();
		Project1 Project= new Project1();
		Project2 ProjectTwo= new Project2();
			
		Project2.useProject2(FileName);
		//Project.useProject1(FileName);
		
		in.close();
	}

	
	
	}


