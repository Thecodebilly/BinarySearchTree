/**
* COP 3538: Project 2 � Stacks and Priority Queues
* 
*
*The purpose of this class is to in-take the .csv file name from the user. The program will then create an array of countries, 
*and sort them by GDP per capita using insertion sort. The program next inputs the countries into a priority queue based on their GDP per capita.
*The program then prints the queues, then stores them into the stack. After all the countries are stored, the stack is then printed to the console
* 
* 
* Billy Shaw
* 2-21-2020
* */
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class Project2 {
	public static void useProject2(String FileName) throws FileNotFoundException {
	
	File file = new File(FileName); 
		Scanner s = new Scanner(file);
		
    ArrayList<Country> arlist= new ArrayList<Country>();
    
    
   
    
    //here you call country.java and use the constructor in order to create the objects
    //at this point the objects are created

    s.nextLine();
	
   do
    {
    	arlist.add(new Country(s.nextLine()));	    
    }	     while (s.hasNextLine());
    		
   				int x=arlist.size();
   
    		 Country[] Countries = new Country [x];
    		 
    		 int i=0;
    while (i<x)
    {
    	Countries[i]=arlist.get(i);
    	i++;
    }
    Project1.insertionSort(Countries, x);
   
    Priority Excellent = new Priority(x);
   
    Priority VGood= new Priority(x);
   
    Priority Good = new Priority(x);
   
    Priority Fair = new Priority(x);
  
    Priority Poor = new Priority(x);
 
    i=0;
    while (i<x)
    {
    if (Countries[i].getNewGDP()/Countries[i].getPopulation()>=50000 )
    {
    	Excellent.insert(Countries[i]);
    }
    else if(Countries[i].getNewGDP()/Countries[i].getPopulation()<50000 && Countries[i].getNewGDP()/Countries[i].getPopulation()>=20000)
    {
    	VGood.insert(Countries[i]);
    }
    else if(Countries[i].getNewGDP()/Countries[i].getPopulation()<20000 && Countries[i].getNewGDP()/Countries[i].getPopulation()>=5000)
    {
    	Good.insert(Countries[i]);
    }
    else if(Countries[i].getNewGDP()/Countries[i].getPopulation()<5000 && Countries[i].getNewGDP()/Countries[i].getPopulation()>=1000)
    {
    	Fair.insert(Countries[i]);
    }
    else
    {
    	Poor.insert(Countries[i]);
    }
    i++;
    }
    Stack StackC = new Stack (x);
    //print queues
  
    System.out.printf("\nExcellent:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
    System.out.printf("Country Name:\t\t              Country Code:     Captiol City:   Population:         GDP:                   Happiness Rank:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
	
    Excellent.printPriority();
   
    System.out.printf("\nVGood:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
    System.out.printf("Country Name:\t\t              Country Code:     Captiol City:   Population:         GDP:                   Happiness Rank:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
	
    VGood.printPriority();
   
    System.out.printf("\nGood:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
    System.out.printf("Country Name:\t\t              Country Code:     Captiol City:   Population:         GDP:                   Happiness Rank:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
	
    Good.printPriority();
   
    System.out.printf("\nFair:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
    System.out.printf("Country Name:\t\t              Country Code:     Captiol City:   Population:         GDP:                   Happiness Rank:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
	
    Fair.printPriority();
   
    System.out.printf("\nPoor:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
    System.out.printf("Country Name:\t\t              Country Code:     Captiol City:   Population:         GDP:                   Happiness Rank:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
	
    Poor.printPriority();
    
    
    
    while (Poor.isEmpty()==false) {
        StackC.push(Poor.remove());
        }
    while (Fair.isEmpty()==false) {
        StackC.push(Fair.remove());
       }
    while (Good.isEmpty()==false) {
        StackC.push(Good.remove());
       }
    while (VGood.isEmpty()==false) {
        StackC.push(VGood.remove());
        }
 
    while (Excellent.isEmpty()==false) {
       StackC.push(Excellent.remove());
    }
    System.out.printf("\nStack:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
	
    StackC.printStack();
    // empty stacks until isEmpty returns false
    
    
    
    
    
    s.close();
}
}
