

public class Country {

	
	private String Name;
	private String Code;
	private String Capitol; 
	private long Population;
	private double newGDP;
	private int HappinessRank;
	public String z;
	public int i=0;
	 public Country (String z) {
	
		String[]temp  = z.split(",");
	
		i=0;
		
	
	this.setName(temp [0]);
	this.setCode(temp [1]);
	this.setCapitol(temp [2]);
	this.setPopulation(Long.parseLong(temp[3]));
	this.setNewGDP(Double.parseDouble(temp[4]));
	this.setHappinessRank(Integer.parseInt(temp[5]));
	
	 }

	public void compare(Country One, Country Two)
	{
		System.out.printf("Country Name:\t%s\nCountry Code:\t%s\nCaptiol City:\t%s\nPopulation:\t%d\nGDP:\t\t%3.2e\nHappiness Rank: %d\n",One.getName(),One.getCode(), One.getCapitol(),One.getPopulation(),One.getNewGDP(),One.getHappinessRank());
		System.out.printf("Country Name:\t%s\nCountry Code:\t%s\nCaptiol City:\t%s\nPopulation:\t%d\nGDP:\t\t%3.2e\nHappiness Rank: %d\n",Two.getName(),Two.getCode(), Two.getCapitol(),Two.getPopulation(),Two.getNewGDP(),Two.getHappinessRank());

	}
	
	public void printCountry (Country One)
	{
		System.out.printf("Country Name:\t%s\nCountry Code:\t%s\nCaptiol City:\t%s\nPopulation:\t%d\nGDP:\t\t%3.2e\nHappiness Rank: %d\n",One.getName(),One.getCode(), One.getCapitol(),One.getPopulation(),One.getNewGDP(),One.getHappinessRank());
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getCode() {
		return Code;
	}

	public void setCode(String code) {
		Code = code;
	}

	public String getCapitol() {
		return Capitol;
	}

	public void setCapitol(String capitol) {
		Capitol = capitol;
	}

	public long getPopulation() {
		return Population;
	}

	public void setPopulation(long l) {
		Population = l;
	}
	
	public double getNewGDP() {
		return newGDP;
	}

	public void setNewGDP(double d) {
		this.newGDP = d;
	}

	public int getHappinessRank() {
		return HappinessRank;
	}

	public void setHappinessRank(int happinessRank) {
		this.HappinessRank = happinessRank;
	}
 
	
	
	
	
	
	
	
	
	
	

}
