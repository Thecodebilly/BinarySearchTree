
	import java.io.FileNotFoundException;
import java.util.*; 
public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		boolean end=false;
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter the name of a file:");
		
		String FileName = in.nextLine();
		Project1 Project= new Project1();
		
			Project.useProject1(FileName);
		
		in.close();
	}

	
	
	}


