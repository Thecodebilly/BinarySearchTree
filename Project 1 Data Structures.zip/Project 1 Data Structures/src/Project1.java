	import java.io.*; 
	import java.util.*; 
public class Project1 {

	    // file scanner
	public void useProject1(String FileName) throws FileNotFoundException {
		
		Scanner in = new Scanner(System.in);
		File file = new File(FileName); 
			Scanner s = new Scanner(file);
			
	    ArrayList<Country> arlist= new ArrayList<Country>();
	    
	    
	   
	    
	    //here you call country.java and use the constructor in order to create the objects
	    //at this point the objects are created
	
	String r = s.nextLine();
	r = s.nextLine();
	arlist.add(new Country(r));
	arlist.add(new Country(r));
	    while (s.hasNextLine())
	    {
	    	
	    	arlist.add(new Country(s.nextLine()));	    
	    }	    
	    		int x=arlist.size();
	    		x--;
	    		 Country[] Countries = new Country [x];
	    		 
	    		 int i=0;
	    while (i<x)
	    {
	    	Countries[i]=arlist.get(i+1);
	    	i++;
	    }
	    
	    //prompting the user
	    String input;
	    int option=0;
	    boolean stop=false;
	    int sort=0;
	    boolean bool;
	    do {
	    do {
	    
	    System.out.println(""
	    		+ "1) Print a countries report\r\n" + 
	    		"2) Sort by Name \r\n" + 
	    		"3) Sort by Happiness Rank \r\n" + 
	    		"4) Sort by GDP per capita\r\n" + 
	    		"5) Find and print a given country \r\n" + 
	    		"6) Quit");
	    
	    //getting choice
	    option=in.nextInt();
	 
	    if (option>6 || option<0)
	    	System.out.println("Invalid, enter a new choice");
	    } while (option>6 || option<0);
	i=0;
	switch(option)
	{
	case 1 :
		System.out.printf("Country Name:\t\t              Country Code:     Captiol City:   Population:         GDP:                   Happiness Rank:\n------------------------------------------------------------------------------------------------------------------------------------------\n");
		
		while(i<x)
			{
			
			System.out.printf("%-35s   %-17s %-15s %-15d     %-3.2e               %-10d\n",Countries[i].getName(),Countries[i].getCode(), Countries[i].getCapitol(),Countries[i].getPopulation(),Countries[i].getNewGDP(),Countries[i].getHappinessRank());
			
			i++;
			}
		
		break;
	case 2 :
		//name
		
		bubbleSort(Countries,x);
		
		
		
		
		sort=1;
		break;
	case 3 :
		 
		//Happiness Rank by selection sort
		
		selectionSort(Countries,x);
		
		sort=2;
		break;
	case 4 :
		//GDP insertion
		
		
		
		insertionSort(Countries,x);
		
		
		
		
		sort=3;
		break;
	case 5 :
		System.out.println("Enter a name to be searched:");
		in.nextLine();
		input=in.nextLine();
		i=0;
		if (sort==1)
		{
			Countries[i].printCountry(binarySearch(Countries,input,x));
		}
		else
		{
		bool=false;	
			do
			{	
				i++;
				bool=input.equals(Countries[i].getName());
					
			}while (false==bool);
			
		
		Countries[i].printCountry(Countries[i]);
		}
		break;
		
	case 6 :
		System.out.println("Adios.");
		s.close();
		in.close();
		stop=true;
		break;
		
	}
	    } while (stop==false);
	s.close();
	in.close();
	
	}
//selection sort
	public static void selectionSort(Country[] countries, int num) {
		for(int outer=0; outer<num-1; outer++) {
		int lowest = outer;
		for(int inner=outer+1; inner<num; inner++) {
		if(countries[inner].getHappinessRank() < countries[lowest].getHappinessRank()) {
		lowest = inner;
		}
		}
		if(lowest != outer) {
		Country temp = countries[lowest];
		countries[lowest] = countries[outer];
		countries[outer] = temp;
		}
		}
		}
	
	
	public static Country binarySearch(Country[] countries, String country,int size)
	{
	int lowerBound = 0;
	int upperBound = size-1;
	int mid=0;
	
	while(lowerBound <= upperBound) {
	mid = (lowerBound + upperBound ) / 2;
	if(countries[mid].getName() == country) {
	return countries[mid]; // found it
	} else if (0<countries[mid].getName().compareTo(country))  {
	upperBound = mid - 1; // it's in lower half
	} else {
	lowerBound = mid + 1; // it's in upper half
	}
	 // probably not right
	}
	return countries[mid];
	}
	

	
	
	public void bubbleSort(Country[] list, int num) {
		int outer=0;
		while (outer<num-1) {
		int inner=num-1;
		while (inner>outer) {
		if (0>list[inner].getName().compareTo(list[inner-1].getName())) {
		Country temp = list[inner];
		list[inner] = list[inner-1];
		list[inner-1] = temp;
		}
		inner--;
		}
		outer++;
		}
}
	public void insertionSort(Country[] list, int num) {
		int inner;
		int outer;
		for(outer=1; outer<num; outer++) { // out is dividing line
		Country temp = list[outer]; // remove marked item
		inner = outer-1; // start shifts at �outer�
		while(inner>=0 && list[inner].getNewGDP()<temp.getNewGDP()) { // until one is smaller
		list[inner+1] = list[inner]; // shift item to right
		inner--; // go left one position
		} // end while
		list[inner+1] = temp; // insert marked item
		} // end for
		} // end insertionSort()
}


